<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import spec from './spec.json'
import { applyAction } from './domain.js'
const key = `generated-demo-${spec.projectId}-${spec.revision}`
const initial = Object.fromEntries(spec.pages.map(page => [page.id, page.rows.map((r, i) => ({ ...r, id: `${page.id}-${i}` }))]))
let loaded
try { loaded = JSON.parse(localStorage.getItem(key)) } catch { /* recover from damaged local data */ }
const data = reactive(loaded && typeof loaded === 'object' && spec.pages.every(p => Array.isArray(loaded[p.id])) ? loaded : initial)
watch(data, () => { try { localStorage.setItem(key, JSON.stringify(data)) } catch { ElMessage.warning('浏览器存储不可用，本次数据仅保留在当前页面') } }, { deep: true })
const route = ref(location.hash.slice(1) || '/')
window.addEventListener('hashchange', () => { route.value = location.hash.slice(1) || '/' })
const page = computed(() => spec.pages.find(p => p.route === route.value))
const query = ref(''), status = ref(''), current = ref(1), size = 8
const sort = reactive({ prop: '', order: '' })
const dialog = ref(false), detail = ref(null), editing = ref(null), form = reactive({})
const selectField = computed(() => page.value?.fields.find(f => f.type === 'select'))
const filtered = computed(() => {
  if (!page.value) return []
  let rows = data[page.value.id].filter(r => Object.values(r).join(' ').toLowerCase().includes(query.value.toLowerCase()) && (!status.value || r[selectField.value?.key] === status.value))
  if (sort.prop && sort.order) rows = [...rows].sort((a, b) => (typeof a[sort.prop] === 'number' ? a[sort.prop] - b[sort.prop] : String(a[sort.prop] ?? '').localeCompare(String(b[sort.prop] ?? ''), 'zh-CN')) * (sort.order === 'ascending' ? 1 : -1))
  return rows
})
watch([route, query, status], () => { current.value = 1 })
watch(route, () => { query.value = ''; status.value = ''; sort.prop = ''; sort.order = '' })
function openForm(row) {
  editing.value = row?.id || null
  for (const k of Object.keys(form)) delete form[k]
  for (const f of page.value.fields) form[f.key] = row?.[f.key] ?? ''
  dialog.value = true
}
function submit() {
  try { data[page.value.id] = applyAction(data[page.value.id], page.value, editing.value ? 'edit' : 'create', form, editing.value); dialog.value = false; ElMessage.success('已保存，概览统计已同步') } catch (e) { ElMessage.error(e.message) }
}
async function remove(row) {
  try { await ElMessageBox.confirm('确定删除这条记录？', '删除确认', { type: 'warning' }); data[page.value.id] = applyAction(data[page.value.id], page.value, 'delete', {}, row.id); current.value = Math.min(current.value, Math.max(1, Math.ceil(filtered.value.length / size))); ElMessage.success('已删除') } catch (e) { if (e instanceof Error) ElMessage.error(e.message) }
}
</script>
<template>
  <div class="shell"><aside><div class="brand"><b>◈</b> {{ spec.title }}</div><small>业务演示工作空间</small><a href="#/" :class="{ active: !page }">▦　数据概览</a><a v-for="p in spec.pages" :key="p.id" :href="`#${p.route}`" :class="{ active: page?.id === p.id }">{{ p.name }}</a><div class="foot">本地演示 · 合成数据</div></aside><main><header><span>{{ spec.title }}</span><span>DEMO / Vue 3</span></header><section v-if="!page"><div class="heading"><div><h1>数据概览</h1><p>{{ spec.description || '查看各模块实时数据，进入页面开始演示。' }}</p></div></div><div class="kpis"><a v-for="p in spec.pages" :href="`#${p.route}`" :key="p.id"><span>{{ p.name }}</span><strong>{{ data[p.id].length }}</strong><small>当前记录　↗</small></a></div><article><h3>本次演示范围</h3><p v-for="item in spec.limitations" :key="item">{{ item }}</p><p>基础交互已提供；需求映射不代表全部业务规则实现或正式验收通过。</p></article></section><section v-else><div class="heading"><div><h1>{{ page.name }}</h1><p>{{ page.description }}</p></div><el-button v-if="page.actions.includes('create')" type="primary" @click="openForm()">新增记录</el-button></div><article class="filters"><el-input v-model="query" placeholder="搜索当前页面记录" clearable style="width: 280px"/><el-select v-if="selectField" v-model="status" placeholder="全部状态" clearable style="width: 160px"><el-option v-for="option in selectField.options" :key="option" :label="option" :value="option"/></el-select><span>{{ filtered.length }} 条记录</span></article><article><el-table :data="filtered.slice((current - 1) * size, current * size)" @sort-change="s => Object.assign(sort, s)"><el-table-column v-for="field in page.fields" :key="field.key" :prop="field.key" :label="field.label" sortable="custom" min-width="150" show-overflow-tooltip><template #default="{ row }"><el-tag v-if="field.type === 'select'">{{ row[field.key] }}</el-tag><span v-else>{{ row[field.key] }}</span></template></el-table-column><el-table-column label="操作" width="170" fixed="right"><template #default="{ row }"><el-button link type="primary" @click="detail = row">详情</el-button><el-button v-if="page.actions.includes('edit')" link type="primary" @click="openForm(row)">编辑</el-button><el-button v-if="page.actions.includes('delete')" link type="danger" @click="remove(row)">删除</el-button></template></el-table-column><template #empty><el-empty description="暂无符合条件的记录"/></template></el-table><el-pagination v-model:current-page="current" :page-size="size" :total="filtered.length" layout="total, prev, pager, next" style="margin-top:20px;justify-content:flex-end"/></article><p class="source">需求依据：{{ page.requirementIds.join(' / ') }} · 当前数据为演示样例</p></section></main></div>
  <el-dialog v-model="dialog" :title="editing ? '编辑记录' : '新增记录'" width="520px" destroy-on-close><el-form label-position="top" @submit.prevent="submit"><el-form-item v-for="field in page?.fields || []" :key="field.key" :label="field.label" :required="field.required"><el-select v-if="field.type === 'select'" v-model="form[field.key]"><el-option v-for="option in field.options" :key="option" :label="option" :value="option"/></el-select><el-date-picker v-else-if="field.type === 'date'" v-model="form[field.key]" value-format="YYYY-MM-DD"/><el-input v-else v-model="form[field.key]" :type="field.type === 'number' ? 'number' : 'text'"/></el-form-item></el-form><template #footer><el-button @click="dialog = false">取消</el-button><el-button type="primary" @click="submit">保存</el-button></template></el-dialog>
  <el-drawer :model-value="!!detail" title="记录详情" @close="detail = null"><el-descriptions :column="1" border><el-descriptions-item v-for="field in page?.fields || []" :key="field.key" :label="field.label">{{ detail?.[field.key] }}</el-descriptions-item></el-descriptions></el-drawer>
</template>
<style>
:root{--el-color-primary:#3263d9;font-family:Inter,'Microsoft YaHei',sans-serif;color:#24334c;background:#f4f6fa}*{box-sizing:border-box}body{margin:0}a{text-decoration:none;color:inherit}.shell{display:flex;min-height:100vh}aside{width:228px;flex-shrink:0;background:#17253d;color:#b9c7dd;padding:28px 18px;display:flex;flex-direction:column;gap:6px;position:fixed;inset:0 auto 0 0;overflow:auto;scrollbar-width:none}aside::-webkit-scrollbar{display:none}.brand{font-weight:700;color:#fff;font-size:17px;line-height:1.6;margin-bottom:34px}.brand b{color:#82a5ff}aside small{font-size:11px;letter-spacing:2px;margin:8px 12px}aside a{padding:13px;border-radius:7px;font-size:14px}aside a.active{background:#3263d9;color:white}.foot{margin-top:auto;padding:30px 10px 0;font-size:12px}main{flex:1;margin-left:228px;min-width:0}header{height:68px;background:white;border-bottom:1px solid #e6ebf2;display:flex;justify-content:space-between;align-items:center;padding:0 34px;font-size:13px}header span:last-child{color:#8490a6}section{padding:32px}.heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px}h1{font-size:27px;margin:0 0 10px}p{color:#7b879a;font-size:13px;line-height:1.8}.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:24px}.kpis a{background:white;border:1px solid #e6ebf2;border-radius:10px;padding:24px;display:flex;flex-direction:column;gap:14px}.kpis strong{font-size:38px;color:#263b64}.kpis small{color:#8b97a9}article{background:white;border:1px solid #e6ebf2;border-radius:10px;padding:24px;margin-bottom:20px}.filters{display:flex;gap:16px;align-items:center}.filters>span{margin-left:auto;font-size:13px;color:#8490a6}.source{font-size:12px}@media(max-width:760px){aside{width:165px}main{margin-left:165px}section{padding:16px}.heading{align-items:flex-start;gap:10px}.filters{flex-wrap:wrap}h1{font-size:22px}}
</style>
