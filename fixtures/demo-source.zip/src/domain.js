export function validateRow(page, input) {
  const result = {}
  for (const f of page.fields) {
    let value = input[f.key] ?? ''
    if (f.required && String(value).trim() === '') throw new Error(`请填写${f.label}`)
    if (f.type === 'number' && value !== '') {
      value = Number(value)
      if (!Number.isFinite(value)) throw new Error(`${f.label}必须是有效数字`)
    }
    if (f.type === 'select' && value !== '' && !f.options.includes(value)) throw new Error(`${f.label}选项无效`)
    if (f.type === 'date' && value !== '' && !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error(`${f.label}日期格式无效`)
    result[f.key] = value
  }
  return result
}
export function applyAction(rows, page, action, input, id) {
  if (!page.actions.includes(action)) throw new Error('此页面未启用该操作')
  if (action === 'create') return [...rows, { ...validateRow(page, input), id: crypto.randomUUID() }]
  if (!rows.some(row => row.id === id)) throw new Error('记录不存在')
  if (action === 'delete') return rows.filter(row => row.id !== id)
  return rows.map(row => row.id === id ? { ...validateRow(page, input), id } : row)
}
